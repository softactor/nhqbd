<div class="container main-menu">
    <div class="row align-items-center justify-content-between d-flex">
        <div id="logo">
            <a href="index.php"><img src="img/logo-nhq.png" alt="" title="" /></a>
        </div>
        <nav id="nav-menu-container">
            <ul class="nav-menu">
                <li class="menu-active"><a href="index.php">Home</a></li>
                <li><a href="about.php">Who we are</a></li>
                <li><a href="services.php">Service</a></li>
                <li><a href="clients.php">Clients</a></li>
                <li><a href="partner.php">Partner</a></li>				          
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav><!-- #nav-menu-container -->		    		
    </div>
</div>