<?php include('header.php'); ?>
<!-- Start Sample Area -->
<section class="sample-text-area section-gap relative">
    <div class="container">
        <h3 class="text-heading">Our Partners</h3>
        <p class="sample-text">
            Every avid independent filmmaker has <b>Bold</b> about making that <i>Italic</i> interest documentary, or short film to show off their creative prowess.
        </p>
    </div>
</section>
<!-- End Sample Area -->
<!-- Start Align Area -->
<div class="whole-wrap">
    <div class="container">
        <div class="section-top-border">
            <h3>Partners Logo</h3>
            <div class="row gallery-item">
                <?php include './partial/partners_logo.php'; ?>
            </div>
        </div>
    </div>
</div>
<!-- End Align Area -->

<?php include('footer.php'); ?>